<?php
include "config/function.php";						//panggil fungsi

get_info("index.php","sebagai halaman utama web");	//informasi

$judul	=	"Home";									//judul dokumen

include "header.php";								//panggil header
?>
		<h1 class="text-center menu">Home</h1>
		<hr>
		<p class="text-justify">
		Sulit dalam memonitoring pengeluaran ataupun pemasukan uang saku
		anda disetiap bulannya? mungkin itu masalah utama anda. Kadang
		anda sendiri tidak mengetahui kenapa uang anda tiba-tiba menipis.
		Itulah hal wajar jika kita hanya diam saja tanpa memperhatikan
		pengeluaran dan pemasukan setiap bulannya.
		</p>
		<p class="text-justify">
		Jangan khawatir akan hal itu, sekarang anda sudah bisa mengetahui
		kemana uang datang dan uang pergi, sehingga anda tidak merasa 
		bingung lagi dengan masalah keuangan anda.
		</p>
		<p  class="text-justify">
		Aplikasi berbasis web ini akan mengajak anda untuk memantau 
		keuangan anda setiap bulannya, asalkan anda mampu memberikan 
		sedikit waktu untuk mengisi rincian setiap harinya, itu sudah
		cukup membantu buat anda.
		</p>
		<p class="text-justify">
		Aplikasi ini sangat mudah digunakan, cocok untuk semua kalangan 
		mulai dari anak-anak, remaja, dewasa maupun lanjut usia.
		</p>
		<p class="text-justify">
		Jangan khawatir, anda menggunakan aplikasi ini tidak memotong 
		pengeluaran anda, hanya anda akses melalui web browser anda. 
		Anda bisa gunakan gadget, smartphone ataupun komputer desktop 
		anda.
		</p>
		<p align="center">
		<a href="#atas"><img src="img/arow.svg" width="60px" height="60px"></a>
